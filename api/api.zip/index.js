const server = require('./app.js');

server.listen(3000);
console.log('servidor iniciado Back Permutas.');