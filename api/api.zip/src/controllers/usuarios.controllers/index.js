const validateUsuario = require('./validateusuario');
const registerUsuario = require('./registerusuario');
const getAllUsuarios = require('./getAllUsuarios');


module.exports={
    validateUsuario,
    registerUsuario,
    getAllUsuarios
}